const $=s=>document.querySelector(s);
const views=["overview","employees","attendance","leaves"];
let me=null;
async function api(path,options={}) {
  const res=await fetch(path,{credentials:"same-origin",headers:{"content-type":"application/json",...(options.headers||{})},...options});
  const data=await res.json().catch(()=>({ok:false,error:"استجابة غير مفهومة"}));
  if(!res.ok) throw new Error(data.error||"تعذر تنفيذ الطلب");
  return data;
}
function notice(msg){const el=$("#notice");el.textContent=msg;el.classList.remove("hidden");setTimeout(()=>el.classList.add("hidden"),4500)}
function showView(name){
  views.forEach(v=>$("#view-"+v).classList.toggle("hidden",v!==name));
  document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  $("#page-title").textContent={overview:"نظرة عامة",employees:"إدارة الموظفين",attendance:"الحضور والانصراف",leaves:"طلبات الإجازات"}[name];
  if(name==="overview") loadDashboard(); if(name==="employees") loadEmployees(); if(name==="attendance") loadAttendance(); if(name==="leaves") loadLeaves();
}
function showApp(user){
  me=user;$("#login-screen").classList.add("hidden");$("#app-screen").classList.remove("hidden");
  $("#logout").classList.remove("hidden");$("#user-label").textContent=`${user.email} · ${user.role}`;
  showView("overview");
}
function showLogin(){$("#app-screen").classList.add("hidden");$("#login-screen").classList.remove("hidden");$("#logout").classList.add("hidden");$("#user-label").textContent="غير مسجل";}
async function loadDashboard(){
  try{const d=await api("/api/dashboard");$("#stat-employees").textContent=d.stats.employees;$("#stat-active").textContent=d.stats.active;$("#stat-leaves").textContent=d.stats.pendingLeaves;$("#stat-attendance").textContent=d.stats.attendanceToday;
  const h=await api("/api/health");$("#health").textContent=h.database==="connected"?"قاعدة البيانات متصلة":"قاعدة البيانات غير متاحة";}
  catch(e){notice(e.message)}
}
async function loadEmployees(){
  try{const d=await api("/api/employees");$("#employees-body").innerHTML=d.employees.map(e=>`<tr><td>${esc(e.full_name)}</td><td>${esc(e.employee_code||"—")}</td><td>${esc(e.department||"—")}</td><td>${esc(e.job_title||"—")}</td><td>${esc(e.status)}</td></tr>`).join("")||'<tr><td colspan="5">لا يوجد موظفون بعد.</td></tr>'}
  catch(e){$("#employees-body").innerHTML=`<tr><td colspan="5">${esc(e.message)}</td></tr>`}
}
async function loadAttendance(){
  try{const d=await api("/api/attendance");$("#attendance-body").innerHTML=d.attendance.map(a=>`<tr><td>${esc(a.full_name)}</td><td>${esc(a.work_date)}</td><td>${esc(a.check_in||"—")}</td><td>${esc(a.check_out||"—")}</td></tr>`).join("")||'<tr><td colspan="4">لا توجد سجلات.</td></tr>'}
  catch(e){$("#attendance-body").innerHTML=`<tr><td colspan="4">${esc(e.message)}</td></tr>`}
}
async function loadLeaves(){
  try{const d=await api("/api/leaves");$("#leaves-list").innerHTML=d.leaves.map(l=>`<div class="leave-item"><div><b>${esc(l.full_name||l.leave_type)}</b><div class="muted">${esc(l.leave_type)} · ${esc(l.start_date)} — ${esc(l.end_date)} · ${esc(l.reason||"بدون سبب")}</div></div><span class="pill">${esc(l.status)}</span>${["owner","admin","hr"].includes(me.role)&&l.status==="pending"?`<button class="quiet" data-review="${l.id}" data-status="approved">موافقة</button><button class="quiet" data-review="${l.id}" data-status="rejected">رفض</button>`:""}</div>`).join("")||'<p class="muted">لا توجد طلبات إجازة.</p>'}
  catch(e){notice(e.message)}
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
document.querySelectorAll(".nav").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("#login-form").addEventListener("submit",async e=>{e.preventDefault();$("#login-msg").textContent="";const f=new FormData(e.currentTarget);try{const d=await api("/api/auth/login",{method:"POST",body:JSON.stringify({email:f.get("email"),password:f.get("password")})});showApp(d.user)}catch(err){$("#login-msg").textContent=err.message}});
$("#logout").addEventListener("click",async()=>{try{await api("/api/auth/logout",{method:"POST",body:"{}"})}finally{showLogin()}});
$("#employee-form").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api("/api/employees",{method:"POST",body:JSON.stringify({fullName:f.get("fullName"),employeeCode:f.get("employeeCode"),department:f.get("department"),jobTitle:f.get("jobTitle"),phone:f.get("phone")})});e.currentTarget.reset();notice("تمت إضافة ملف الموظف.");loadEmployees()}catch(err){notice(err.message)}});
$("#clock").addEventListener("click",async()=>{try{const d=await api("/api/attendance/clock",{method:"POST",body:"{}"});notice(d.action==="check_in"?"تم تسجيل الحضور.":"تم تسجيل الانصراف.");loadAttendance()}catch(e){notice(e.message)}});
$("#leave-form").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api("/api/leaves",{method:"POST",body:JSON.stringify({leaveType:f.get("leaveType"),startDate:f.get("startDate"),endDate:f.get("endDate"),reason:f.get("reason")})});e.currentTarget.reset();notice("تم إرسال طلب الإجازة.");loadLeaves()}catch(err){notice(err.message)}});
$("#leaves-list").addEventListener("click",async e=>{const b=e.target.closest("[data-review]");if(!b)return;try{await api(`/api/leaves/${b.dataset.review}/review`,{method:"PATCH",body:JSON.stringify({status:b.dataset.status})});notice("تم تحديث حالة الطلب.");loadLeaves()}catch(err){notice(err.message)}});
(async()=>{try{const d=await api("/api/auth/me");showApp(d.user)}catch{showLogin()}})();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));