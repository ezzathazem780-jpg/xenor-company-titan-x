const SESSION_DAYS = 7;
const PBKDF2_ITERATIONS = 310000;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
  });
}
function fail(message, status = 400) { return json({ ok: false, error: message }, status); }
function uuid() { return crypto.randomUUID(); }
function cookieValue(request, name) {
  const raw = request.headers.get("Cookie") || "";
  const part = raw.split(";").map(x => x.trim()).find(x => x.startsWith(name + "="));
  return part ? decodeURIComponent(part.slice(name.length + 1)) : null;
}
function cookieHeader(value, maxAge) {
  return `xenor_session=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
async function sha256(value) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, "0")).join("");
}
function randomHex(size = 16) {
  const bytes = crypto.getRandomValues(new Uint8Array(size));
  return [...bytes].map(b => b.toString(16).padStart(2, "0")).join("");
}
async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: new TextEncoder().encode(salt), iterations: PBKDF2_ITERATIONS, hash: "SHA-256" },
    key, 256
  );
  return [...new Uint8Array(bits)].map(b => b.toString(16).padStart(2, "0")).join("");
}
async function readBody(request) {
  try { return await request.json(); } catch { return null; }
}
function validEmail(v) { return typeof v === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length <= 190; }
function validPassword(v) { return typeof v === "string" && v.length >= 12 && v.length <= 200; }
function sameOrigin(request) {
  const origin = request.headers.get("Origin");
  if (!origin) return true;
  try { return new URL(origin).host === new URL(request.url).host; } catch { return false; }
}
async function audit(env, actor, action, entityType = null, entityId = null, details = {}) {
  await env.DB.prepare(
    "INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json) VALUES (?, ?, ?, ?, ?, ?)"
  ).bind(uuid(), actor?.id || null, action, entityType, entityId, JSON.stringify(details)).run();
}
async function currentUser(request, env) {
  const token = cookieValue(request, "xenor_session");
  if (!token) return null;
  const hash = await sha256(token);
  const row = await env.DB.prepare(
    `SELECT u.id, u.email, u.role, u.is_active
     FROM sessions s JOIN users u ON u.id=s.user_id
     WHERE s.token_hash=? AND s.expires_at > datetime('now') AND u.is_active=1`
  ).bind(hash).first();
  return row || null;
}
function requireRole(user, roles) { return !!user && roles.includes(user.role); }
async function createSession(userId, env) {
  const token = randomHex(32);
  const hash = await sha256(token);
  await env.DB.prepare("INSERT INTO sessions (token_hash,user_id,expires_at) VALUES (?, ?, datetime('now', ?))")
    .bind(hash, userId, `+${SESSION_DAYS} days`).run();
  return token;
}
async function setup(request, env) {
  if (!env.SETUP_KEY) return fail("إعداد مفتاح التأسيس غير مكتمل على الخادم.", 503);
  const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM users").first();
  if (Number(count?.n || 0) > 0) return fail("تم إنشاء حساب المالك بالفعل.", 409);
  const body = await readBody(request);
  if (!body || body.setupKey !== env.SETUP_KEY) return fail("مفتاح التأسيس غير صحيح.", 403);
  if (!validEmail(body.email) || !validPassword(body.password) || typeof body.fullName !== "string" || body.fullName.trim().length < 2)
    return fail("أدخل اسمًا وبريدًا صحيحًا وكلمة مرور لا تقل عن 12 حرفًا.");
  const id = uuid(), salt = randomHex(16), hash = await passwordHash(body.password, salt);
  await env.DB.prepare("INSERT INTO users (id,email,password_hash,password_salt,role) VALUES (?,?,?,?, 'owner')")
    .bind(id, body.email.trim().toLowerCase(), hash, salt).run();
  await env.DB.prepare("INSERT INTO employees (id,user_id,full_name,job_title,status) VALUES (?,?,?,'Owner','active')")
    .bind(uuid(), id, body.fullName.trim()).run();
  await audit(env, {id}, "owner.bootstrap", "user", id);
  const token = await createSession(id, env);
  return json({ ok: true, user: { id, email: body.email.trim().toLowerCase(), role: "owner" } }, 201,
    { "set-cookie": cookieHeader(token, SESSION_DAYS * 86400) });
}
async function login(request, env) {
  const body = await readBody(request);
  if (!body || !validEmail(body.email) || typeof body.password !== "string") return fail("بيانات الدخول غير صحيحة.", 401);
  const user = await env.DB.prepare("SELECT * FROM users WHERE email=? COLLATE NOCASE").bind(body.email.trim()).first();
  if (!user || !user.is_active) return fail("بيانات الدخول غير صحيحة.", 401);
  const computed = await passwordHash(body.password, user.password_salt);
  if (computed !== user.password_hash) return fail("بيانات الدخول غير صحيحة.", 401);
  const token = await createSession(user.id, env);
  await audit(env, {id:user.id}, "auth.login", "user", user.id);
  return json({ ok: true, user: { id:user.id, email:user.email, role:user.role } }, 200,
    { "set-cookie": cookieHeader(token, SESSION_DAYS * 86400) });
}
async function logout(request, env) {
  const token = cookieValue(request, "xenor_session");
  if (token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha256(token)).run();
  return json({ ok:true }, 200, { "set-cookie": cookieHeader("", 0) });
}
async function route(request, env) {
  const url = new URL(request.url), path = url.pathname, method = request.method;
  if (path.startsWith("/api/") && !sameOrigin(request) && !["GET","HEAD","OPTIONS"].includes(method)) return fail("طلب غير مسموح.", 403);
  if (method === "OPTIONS") return new Response(null, { status:204, headers:{ "Allow":"GET,POST,PATCH,DELETE,OPTIONS" } });
  if (path === "/api/health" && method === "GET") {
    try { await env.DB.prepare("SELECT 1").first(); return json({ ok:true, service:"XENOR COMPANY", database:"connected" }); }
    catch { return json({ ok:false, service:"XENOR COMPANY", database:"unavailable" }, 503); }
  }
  if (path === "/api/setup" && method === "POST") return setup(request, env);
  if (path === "/api/auth/login" && method === "POST") return login(request, env);
  if (path === "/api/auth/logout" && method === "POST") return logout(request, env);

  const user = await currentUser(request, env);
  if (path === "/api/auth/me" && method === "GET")
    return user ? json({ ok:true, user }) : fail("يلزم تسجيل الدخول.", 401);
  if (!user) return fail("يلزم تسجيل الدخول.", 401);

  if (path === "/api/dashboard" && method === "GET") {
    const [employees, active, pending, today] = await Promise.all([
      env.DB.prepare("SELECT COUNT(*) n FROM employees").first(),
      env.DB.prepare("SELECT COUNT(*) n FROM employees WHERE status='active'").first(),
      env.DB.prepare("SELECT COUNT(*) n FROM leave_requests WHERE status='pending'").first(),
      env.DB.prepare("SELECT COUNT(*) n FROM attendance WHERE work_date=date('now')").first()
    ]);
    return json({ ok:true, stats:{ employees:employees.n, active:active.n, pendingLeaves:pending.n, attendanceToday:today.n } });
  }
  if (path === "/api/employees" && method === "GET") {
    if (!requireRole(user, ["owner","admin","hr"])) return fail("ليس لديك صلاحية.", 403);
    const rows = await env.DB.prepare(
      `SELECT e.id,e.employee_code,e.full_name,e.phone,e.department,e.job_title,e.hire_date,e.status,u.email
       FROM employees e LEFT JOIN users u ON u.id=e.user_id ORDER BY e.created_at DESC LIMIT 500`
    ).all();
    return json({ ok:true, employees:rows.results });
  }
  if (path === "/api/employees" && method === "POST") {
    if (!requireRole(user, ["owner","admin","hr"])) return fail("ليس لديك صلاحية.", 403);
    const b = await readBody(request);
    if (!b || typeof b.fullName !== "string" || b.fullName.trim().length < 2) return fail("اسم الموظف مطلوب.");
    const id = uuid();
    await env.DB.prepare(
      "INSERT INTO employees (id,employee_code,full_name,phone,department,job_title,hire_date) VALUES (?,?,?,?,?,?,?)"
    ).bind(id, b.employeeCode || null, b.fullName.trim(), b.phone || null, b.department || null, b.jobTitle || null, b.hireDate || null).run();
    await audit(env,user,"employee.created","employee",id);
    return json({ ok:true, id },201);
  }
  if (path === "/api/attendance/clock" && method === "POST") {
    const employee = await env.DB.prepare("SELECT id FROM employees WHERE user_id=? AND status='active'").bind(user.id).first();
    if (!employee) return fail("لا يوجد ملف موظف نشط مرتبط بحسابك.", 404);
    const existing = await env.DB.prepare("SELECT * FROM attendance WHERE employee_id=? AND work_date=date('now')").bind(employee.id).first();
    if (!existing) {
      await env.DB.prepare("INSERT INTO attendance (id,employee_id,work_date,check_in) VALUES (?,?,date('now'),datetime('now'))")
        .bind(uuid(),employee.id).run();
      return json({ok:true, action:"check_in"});
    }
    if (existing.check_out) return fail("تم تسجيل الانصراف لهذا اليوم بالفعل.",409);
    await env.DB.prepare("UPDATE attendance SET check_out=datetime('now') WHERE id=?").bind(existing.id).run();
    return json({ok:true, action:"check_out"});
  }
  if (path === "/api/attendance" && method === "GET") {
    if (!requireRole(user, ["owner","admin","hr"])) return fail("ليس لديك صلاحية.",403);
    const rows = await env.DB.prepare(
      `SELECT a.*,e.full_name,e.employee_code FROM attendance a JOIN employees e ON e.id=a.employee_id
       ORDER BY a.work_date DESC,a.check_in DESC LIMIT 300`
    ).all();
    return json({ok:true,attendance:rows.results});
  }
  if (path === "/api/leaves" && method === "GET") {
    let rows;
    if (requireRole(user,["owner","admin","hr"])) {
      rows = await env.DB.prepare(
        `SELECT l.*,e.full_name FROM leave_requests l JOIN employees e ON e.id=l.employee_id
         ORDER BY l.created_at DESC LIMIT 300`).all();
    } else {
      const e = await env.DB.prepare("SELECT id FROM employees WHERE user_id=?").bind(user.id).first();
      rows = e ? await env.DB.prepare("SELECT * FROM leave_requests WHERE employee_id=? ORDER BY created_at DESC").bind(e.id).all() : {results:[]};
    }
    return json({ok:true,leaves:rows.results});
  }
  if (path === "/api/leaves" && method === "POST") {
    const e = await env.DB.prepare("SELECT id FROM employees WHERE user_id=? AND status='active'").bind(user.id).first();
    if (!e) return fail("لا يوجد ملف موظف مرتبط بحسابك.",404);
    const b = await readBody(request);
    if (!b || !b.leaveType || !b.startDate || !b.endDate || b.endDate < b.startDate) return fail("بيانات طلب الإجازة غير مكتملة.");
    const id=uuid();
    await env.DB.prepare(
      "INSERT INTO leave_requests (id,employee_id,leave_type,start_date,end_date,reason) VALUES (?,?,?,?,?,?)"
    ).bind(id,e.id,b.leaveType,b.startDate,b.endDate,b.reason || null).run();
    await audit(env,user,"leave.created","leave_request",id);
    return json({ok:true,id},201);
  }
  const reviewMatch = path.match(/^\/api\/leaves\/([0-9a-f-]+)\/review$/i);
  if (reviewMatch && method === "PATCH") {
    if (!requireRole(user,["owner","admin","hr"])) return fail("ليس لديك صلاحية.",403);
    const b=await readBody(request);
    if (!b || !["approved","rejected"].includes(b.status)) return fail("قرار المراجعة غير صحيح.");
    const result=await env.DB.prepare(
      "UPDATE leave_requests SET status=?,reviewed_by=?,reviewed_at=datetime('now') WHERE id=? AND status='pending'"
    ).bind(b.status,user.id,reviewMatch[1]).run();
    if (!result.meta.changes) return fail("الطلب غير موجود أو تمت مراجعته مسبقًا.",404);
    await audit(env,user,"leave.reviewed","leave_request",reviewMatch[1],{status:b.status});
    return json({ok:true});
  }
  if (path === "/api/audit" && method === "GET") {
    if (!requireRole(user,["owner","admin"])) return fail("ليس لديك صلاحية.",403);
    const rows=await env.DB.prepare(
      `SELECT a.id,a.action,a.entity_type,a.entity_id,a.details_json,a.created_at,u.email
       FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_user_id ORDER BY a.created_at DESC LIMIT 200`
    ).all();
    return json({ok:true,logs:rows.results});
  }
  return fail("المسار غير موجود.",404);
}
export default {
  async fetch(request, env) {
    try {
      if (new URL(request.url).pathname.startsWith("/api/")) return await route(request,env);
      return env.ASSETS.fetch(request);
    } catch (error) {
      console.error(JSON.stringify({ level:"error", message:"request_failed", path:new URL(request.url).pathname }));
      return fail("حدث خطأ داخلي. راجع سجلات الخادم.",500);
    }
  }
};